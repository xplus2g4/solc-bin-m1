****************
Language Grammar
****************

.. a4:autogrammar:: Solidity
   :only-reachable-from: Solidity.sourceUnit
   :undocumented:
   :cc-to-dash:

.. a4:autogrammar:: SolidityLexer
   :only-reachable-from: Solidity.sourceUnit
   :fragments:
   :cc-to-dash: