#!/bin/bash

# If we ever want to patch the binaries e.g. for compatibility with older solc-js versions,
# we can do that here.
#
# This script gets the following parameters:
# - TAG
# - SOLJSON_JS
